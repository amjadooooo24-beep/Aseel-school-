مدرسة أصيل — فصل الفيديو باستخدام LiveKit وNetlify

محتويات الحزمة:
- index.html: واجهة الموقع مع الفصل الافتراضي.
- netlify/functions/get-token.mjs: وظيفة آمنة مبدئياً لإنشاء رمز LiveKit.
- netlify.toml و package.json: إعدادات البناء.

مهم:
1) لا ترفع هذا المشروع كملفات HTML فقط عبر Netlify Drop وتتوقع تشغيل Functions؛ يجب نشر المشروع بطريقة تنفذ بناء Netlify، مثل ربط مستودع GitHub بموقع Netlify أو استخدام Netlify CLI.
2) في Netlify > Site configuration > Environment variables أضف:
   LIVEKIT_URL
   LIVEKIT_API_KEY
   LIVEKIT_API_SECRET
   CLASSROOM_ACCESS_CODE
3) ضع القيم السرية داخل Netlify فقط. لا تضع API Secret في index.html ولا ترسله لأحد.
4) بعد إضافة/تغيير المتغيرات أعد النشر.
5) رمز CLASSROOM_ACCESS_CODE مشترك وبسيط كبداية، وليس نظام حسابات فردية. لا تستخدمه كحماية قوية لفصول الأطفال؛ يلزم لاحقاً تسجيل دخول وصلاحيات فردية.

هذه الحزمة لا تحتوي على مفاتيح LiveKit أو أي أسرار.
