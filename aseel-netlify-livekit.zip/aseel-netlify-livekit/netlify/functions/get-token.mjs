import { AccessToken } from "livekit-server-sdk";

const json = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
  },
  body: JSON.stringify(body),
});

export default async (request) => {
  if (request.method !== "POST") {
    return json(405, { error: "طريقة الطلب غير مسموحة." });
  }

  try {
    const {
      LIVEKIT_URL,
      LIVEKIT_API_KEY,
      LIVEKIT_API_SECRET,
      CLASSROOM_ACCESS_CODE,
    } = process.env;

    if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET || !CLASSROOM_ACCESS_CODE) {
      return json(500, { error: "إعدادات الفصل غير مكتملة في Netlify." });
    }

    const body = JSON.parse(request.body || "{}");
    const identity = String(body.identity || "").trim().slice(0, 50);
    const room = String(body.room || "").trim();
    const accessCode = String(body.accessCode || "");

    if (!identity || !/^[A-Za-z0-9_-]{1,60}$/.test(room) || !accessCode) {
      return json(400, { error: "يرجى إدخال الاسم ورمز الفصل ورمز الدخول بشكل صحيح." });
    }

    if (accessCode !== CLASSROOM_ACCESS_CODE) {
      return json(401, { error: "رمز الدخول غير صحيح. تواصل مع إدارة مدرسة أصيل." });
    }

    const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity,
      name: identity,
      ttl: "2h",
    });

    token.addGrant({
      roomJoin: true,
      room,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true,
    });

    return json(200, {
      url: LIVEKIT_URL,
      token: await token.toJwt(),
    });
  } catch (error) {
    return json(400, { error: "تعذر إنشاء رمز الدخول. تحقق من البيانات وحاول مجدداً." });
  }
};
